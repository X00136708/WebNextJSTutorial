import Header from '../components/header'
import Layout from '../components/myLayout'
export default () =>(

<Layout>
<p>Hi there</p>
</Layout>

)